// Toggle Class Active untuk hamburger menu
const navbarNav = document.querySelector ('.navbar-nav');
// Ketika hamburger menu diklik
document.querySelector('#hamburger-menu').onclick = (e) => {
    navbarNav.classList.toggle('active');
    e.preventDefault();
};

// Klik di luar elemen
const hm = document.querySelector('#hamburger-menu');

document.addEventListener('click', function(e) {
    if(!hm.contains(e.target) && !navbarNav.contains(e.target)) {
        navbarNav.classList.remove('active');
    }
});


//  nav

function scrollValue() {
    var navbar = document.getElementById('navbar');
    var scroll = window.scrollY;
    if (scroll < 900) {
        navbar.classList.remove('BgColour');
    } else {
        navbar.classList.add('BgColour');
    }
}

window.addEventListener('scroll', scrollValue);


// Slider
var TrandingSlider = new Swiper('.mySwiper', {
  effect: 'coverflow',
  grabCursor: true,
  centeredSlides: true,
  loop: true,
  autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
  slidesPerView: 'auto',
  coverflowEffect: {
    rotate: 0,
    stretch: 0,
    depth: 100,
    modifier: 1,
  },
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
  }
});


// Contact


   function sendMail() {
    var params = {
      name: document.getElementById("name").value,
      email: document.getElementById("email").value,
      number: document.getElementById("number").value,
      message: document.getElementById("message").value,
    };
  
    const serviceID = "service_h7zdopj";
    const templateID = "template_mfxovac";


    const popup = document.querySelector('.popup');
    
    emailjs.send(serviceID, templateID, params)
    .then(res=>{
        document.getElementById("name").value = "";
        document.getElementById("email").value = "";
        document.getElementById("number").value = "";
        document.getElementById("message").value = "";
        console.log(res);
        //   alert("Your message sent successfully!!")
        // Toggle Class Active untuk send message
        
        
    // Ketika send diklik    
    })
    .catch(err=>console.log(err));
    
    if(res = 200) {
        popup.classList.add('active');
    };
  }

// Close Pop Up Button
  function closePopUp() {
    popup.classList.remove("active");
}

// Klik di luar elemen
document.addEventListener('click', function(e) {
    if(!popup.contains(e.target)) {
        popup.classList.remove('active');
    }
});



// Modal Box 1
const itemDetailModal1 = document.querySelector('#detail-modal1');
const itemDetailButtons1 = document.querySelectorAll('#detail-button1');


itemDetailButtons1.forEach((btn) => {
    btn.onclick = (e) => {
        itemDetailModal1.style.display = 'flex';
        e.preventDefault();
    }
})

// Klik tombol close modal
document.querySelector('.modal1 .close-icon').onclick = (e) => {
    itemDetailModal1.style.display = 'none';
    e.preventDefault();
}

// Modal Box 2
const itemDetailModal2 = document.querySelector('#detail-modal2');
const itemDetailButtons2 = document.querySelectorAll('#detail-button2');


itemDetailButtons2.forEach((btn) => {
    btn.onclick = (e) => {
        itemDetailModal2.style.display = 'flex';
        e.preventDefault();
    }
})

// Klik tombol close modal
document.querySelector('.modal2 .close-icon').onclick = (e) => {
    itemDetailModal2.style.display = 'none';
    e.preventDefault();
}

// Modal Box 3
const itemDetailModal3 = document.querySelector('#detail-modal3');
const itemDetailButtons3 = document.querySelectorAll('#detail-button3');


itemDetailButtons3.forEach((btn) => {
    btn.onclick = (e) => {
        itemDetailModal3.style.display = 'flex';
        e.preventDefault();
    }
})

// Klik tombol close modal
document.querySelector('.modal3 .close-icon').onclick = (e) => {
    itemDetailModal3.style.display = 'none';
    e.preventDefault();
}

// Klik di luar modal
window.onclick = (e) => {
    if (e.target === itemDetailModal1) {
        itemDetailModal1.style.display = 'none';
    }
    if (e.target === itemDetailModal2) {
        itemDetailModal2.style.display = 'none';
    }
    if (e.target === itemDetailModal3) {
        itemDetailModal3.style.display = 'none';
    }
}